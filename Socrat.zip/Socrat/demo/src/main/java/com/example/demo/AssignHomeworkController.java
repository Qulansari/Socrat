package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class AssignHomeworkController {

    @FXML
    private Button backBttn;

    @FXML
    public void teacherBack(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("menu-teacher.fxml");

    }

}
