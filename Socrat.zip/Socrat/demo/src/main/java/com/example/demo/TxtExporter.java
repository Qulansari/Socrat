package com.example.demo;

import javafx.collections.ObservableList;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TxtExporter {
    public static void exportToTxt(String fileName, ObservableList<StudentAttendance> data) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {

            writer.write("Student ID\tStudent Name\tStudent Surname\tDate\tStatus");
            writer.newLine();


            for (StudentAttendance student : data) {
                writer.write(String.format("%s\t\t%s\t\t%s\t\t%s\t\t%s",
                        student.getId_table(), student.getName_table(), student.getSurname_table(),
                        student.getDate_table(), student.getStatus_table()));
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();

        }
    }
}
