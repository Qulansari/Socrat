package com.example.demo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;


public class SignUpController {
    @FXML
    private Button backButton;

    @FXML
    private Button adduserButton;

    @FXML
    private Button deleteUserButton;

    @FXML
    private PasswordField newPass;

    @FXML
    private PasswordField repeatNewPass;

    @FXML
    private Label TextAfterCreateAcc;

    @FXML
    private TextField email;

    @FXML
    private TextField name;

    @FXML
    private TextField phone;

    @FXML
    private TextField surname;



    public void userBack(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("log-in.fxml");
    }

    @FXML
    public void addUser(ActionEvent event) throws IOException {
        checkData();
    }

    private void checkData() {
            if(name.getText().isEmpty() && surname.getText().isEmpty() && email.getText().isEmpty() && phone.getText().isEmpty() && newPass.getText().isEmpty() && repeatNewPass.getText().isEmpty()){
                TextAfterCreateAcc.setText("Please enter data!");
            }
            else if(name.getText().isEmpty()) {
                TextAfterCreateAcc.setText("Please enter a name!");
            }
            else if(surname.getText().isEmpty()) {
                TextAfterCreateAcc.setText("Please enter a surname!");
            }
            else if(email.getText().isEmpty()) {
                TextAfterCreateAcc.setText("Please enter a Email!");
            }
            else if(phone.getText().isEmpty()) {
                TextAfterCreateAcc.setText("Please enter a Phone Number!");
            }
            else if(newPass.getText().isEmpty() && repeatNewPass.getText().isEmpty()) {
                TextAfterCreateAcc.setText("Please enter a password!");
            }
            else if(repeatNewPass.getText().isEmpty()) {
                TextAfterCreateAcc.setText("Please confirm your password!");
            }
            else if(newPass.getText().equals(repeatNewPass.getText())) {
                TextAfterCreateAcc.setText("User have added successfully");
            }
            else {
                TextAfterCreateAcc.setText("No matches");
            }
    }

    @FXML
    public void deleteUser(ActionEvent event) throws IOException {
          checkData_2();
    }

    private void checkData_2(){
        if(name.getText().isEmpty() && surname.getText().isEmpty() && email.getText().isEmpty() && phone.getText().isEmpty() && newPass.getText().isEmpty() && repeatNewPass.getText().isEmpty()){
            TextAfterCreateAcc.setText("Please enter data!");
        }
        else if(name.getText().isEmpty()) {
            TextAfterCreateAcc.setText("Please enter a name!");
        }
        else if(surname.getText().isEmpty()) {
            TextAfterCreateAcc.setText("Please enter a surname!");
        }
        else if(email.getText().isEmpty()) {
            TextAfterCreateAcc.setText("Please enter a Email!");
        }
        else if(phone.getText().isEmpty()) {
            TextAfterCreateAcc.setText("Please enter a Phone Number!");
        }
        else if(newPass.getText().isEmpty() && repeatNewPass.getText().isEmpty()) {
            TextAfterCreateAcc.setText("Please enter a password!");
        }
        else if(repeatNewPass.getText().isEmpty()) {
            TextAfterCreateAcc.setText("Please confirm your password!");
        }
        else if(newPass.getText().equals(repeatNewPass.getText())) {
            TextAfterCreateAcc.setText("User have deleted successfully");
        }
        else {
            TextAfterCreateAcc.setText("No matches");
        }
    }


}
