package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class MenuTeacherController {
    @FXML
    private Button logOutBttn;
    @FXML
    private Button assignHomeworkBttn;

    @FXML
    private Button attendanceBttn;

    @FXML
    private Button gradesBttn;
    @FXML
    private Button studentListBttn;

    @FXML
    public void teacherLogOut(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("log-in.fxml");
    }

    @FXML
    public void teacherAttendance(ActionEvent event) throws IOException {
         Main m = new Main();
         m.changeScene("attendance-for-teacher.fxml");
    }

    @FXML
    void teacherGrades(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("grades-for-teacher.fxml");
    }

    @FXML
    void teacherHomework(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("assign-homework.fxml");
    }

    @FXML
    void teacherStudentList(ActionEvent event) throws IOException{
        Main m = new Main();
        m.changeScene("student-list-for-teacher.fxml");

    }
}
