package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class MenuStudentController {

    @FXML
    private Button logOutBttn;
    @FXML
    private Button viewGradesBttn;

    @FXML
    private Button viewHomeworkBttn;

    @FXML
    private Button viewScheduleBttn;

    @FXML
    public void studentViewGrades(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("grades-for-student.fxml");
    }

    @FXML
    public void studentViewHomework(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("homework-for-student.fxml");
    }

    @FXML
    public void studentViewSchedule(ActionEvent event) throws IOException{
        Main m = new Main();
        m.changeScene("schedule-for-student.fxml");
    }

    @FXML
    public void studentLogOut(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("log-in.fxml");
    }

}
