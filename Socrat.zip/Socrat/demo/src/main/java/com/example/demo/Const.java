package com.example.demo;

public class Const {
    public static final String STUDENT_TABLE = "student";
    public static final String STUDENT_ID = "student_id";
    public static final String STUDENT_NAME = "student_name";
    public static final String STUDENT_SURNAME = "student_surname";
    public static final String STUDENT_PASSWORD = "student_surname";
}
