package com.example.demo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class MenuAdminController {

    @FXML
    private Button logOutBttn;
    @FXML
    private Button usersBttn;
    @FXML
    private Button scheduleBttn;

    public void adminLogOut(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("log-in.fxml");
    }

    public void adminUsers(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("sign-up.fxml");
    }

    public void adminSchedule(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("schedule-for-admin.fxml");
    }


}


