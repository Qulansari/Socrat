package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


import java.io.IOException;



public class ForgetPasswordController {
    @FXML
    private Button backToLoginButton;

    @FXML
    private Label afterProceedButton;
    @FXML
    private TextField email;

    @FXML
    private PasswordField newPass;

    @FXML
    private PasswordField password;
    @FXML
    private Button proceedButton;

    @FXML
    public void userBackToLogin(ActionEvent event) throws IOException  {
        Main m = new Main();
        m.changeScene("log-in.fxml");
    }

    public void userProceed(ActionEvent event) throws IOException {
        checkData();
    }

    private void checkData(){
        if(email.getText().isEmpty() && password.getText().isEmpty() && newPass.getText().isEmpty()){
            afterProceedButton.setText("Please enter your data!");
        }
        else if(email.getText().isEmpty()){
            afterProceedButton.setText("Pleas enter an email!");
        }
        else if(password.getText().isEmpty() && newPass.getText().isEmpty()) {
            afterProceedButton.setText("Please enter a password!");
        }
        else if(newPass.getText().isEmpty()) {
            afterProceedButton.setText("Please repeat your password!");
        }
        else if(password.getText().equals(newPass.getText())) {
            afterProceedButton.setText("Your request have proceeded");
        }
        else {
            afterProceedButton.setText("No matches");
        }
    }
}
