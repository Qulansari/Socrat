package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;


import java.io.IOException;


public class LogInController {

    public LogInController() {

    }

    @FXML
    private Button loginButton;

    @FXML
    private PasswordField password;

    @FXML
    private TextField username;

    @FXML
    private Label wrongLogin;

    @FXML
    private Button ForgetPasswordButton;



    public void userLogin(ActionEvent event) throws IOException {
        checkLogin();
    }

    private void checkLogin() throws IOException {
        Main m = new Main();
        if (username.getText().equals("admin") && password.getText().equals("admin")) {
            wrongLogin.setText("Welcome!");

            m.changeScene("menu-admin.fxml");
        }
        else if(username.getText().equals("teacher") && password.getText().equals("teacher")) {
            wrongLogin.setText("Welcome!");

            m.changeScene("menu-teacher.fxml");
        }
        else if(username.getText().equals("student") && password.getText().equals("student")){
            wrongLogin.setText("Welcome!");

            m.changeScene("menu-student.fxml");
        }
        else if (username.getText().isEmpty() && password.getText().isEmpty()) {
            wrongLogin.setText("Please enter your data.");
        } else {
            wrongLogin.setText("Wrong username or password!");
        }
    }

    public void userForgetPassword(ActionEvent event) throws IOException {
        clickForgetPassButton();
    }

    private void clickForgetPassButton() throws IOException {
        Main m = new Main();
        m.changeScene("forget-password.fxml");
    }


}


