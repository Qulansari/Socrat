package com.example.demo;



public class StudentAttendance {
    private String id_table;
    private String name_table;
    private String surname_table;
    private String date_table;
    private String status_table;

    public StudentAttendance() {

    }

    public StudentAttendance(String id, String name, String surname, String date, String status) {
        this.id_table = id;
        this.name_table = name;
        this.surname_table = surname;
        this.date_table = date;
        this.status_table = status;
    }

    public String getId_table() {
        return id_table;
    }

    public void setId_table(String id_table) {
        this.id_table = id_table;
    }

    public String getName_table() {
        return name_table;
    }

    public void setName_table(String name_table) {
        this.name_table = name_table;
    }

    public String getSurname_table() {
        return surname_table;
    }

    public void setSurname_table(String surname_table) {
        this.surname_table = surname_table;
    }

    public String getDate_table() {
        return date_table;
    }

    public void setDate_table(String date_table) {
        this.date_table = date_table;
    }

    public String getStatus_table() {
        return status_table;
    }

    public void setStatus_table(String status_table) {
        this.status_table = status_table;
    }
}
