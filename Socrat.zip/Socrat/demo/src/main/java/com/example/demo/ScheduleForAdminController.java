package com.example.demo;

import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import java.io.IOException;

public class ScheduleForAdminController {

    @FXML
    private Button BackBttn;


    public void adminBack(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("menu-admin.fxml");
    }
}
