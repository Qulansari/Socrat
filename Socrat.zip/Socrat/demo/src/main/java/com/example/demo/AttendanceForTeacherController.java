package com.example.demo;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;


import java.io.File;
import java.io.IOException;

public class AttendanceForTeacherController {

    @FXML
    private Button backBttn;
    @FXML
    private Button add_button;
    @FXML
    private Button delete_button;
    @FXML
    private Button save_button;
    @FXML
    private Label attention_message;

    @FXML
    private TableColumn<StudentAttendance, String> date_table;

    @FXML
    private TableColumn<StudentAttendance, String> id_table;

    @FXML
    private TableColumn<StudentAttendance, String> status_table;

    @FXML
    private TableColumn<StudentAttendance, String> name_table;

    @FXML
    private TableColumn<StudentAttendance, String> surname_table;

    @FXML
    private TableView<StudentAttendance> table;
    @FXML
    private DatePicker date_textField;
    @FXML
    private TextField id_textField;
    @FXML
    private TextField name_textField;
    @FXML
    private TextField status_textField;
    @FXML
    private TextField surname_textField;




    @FXML
    void teacherBack(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("menu-teacher.fxml");
    }

    public void initialize() {
        id_table.setCellValueFactory(new PropertyValueFactory<>("id_table"));
        name_table.setCellValueFactory(new PropertyValueFactory<>("name_table"));
        surname_table.setCellValueFactory(new PropertyValueFactory<>("surname_table"));
        date_table.setCellValueFactory(new PropertyValueFactory<>("date_table"));
        status_table.setCellValueFactory(new PropertyValueFactory<>("status_table"));
    }


    @FXML
    public void addAttendance(ActionEvent event) throws IOException{
        String id = id_textField.getText();
        String name = name_textField.getText();
        String surname = surname_textField.getText();
        String date = date_textField.getValue().toString();
        String status = status_textField.getText();

        StudentAttendance student_data = new StudentAttendance(id, name, surname, date, status);

        if (table.getItems() == null) {
            table.setItems(FXCollections.observableArrayList(student_data));
        } else {
            table.getItems().add(student_data);
        }

            id_textField.clear();
            name_textField.clear();
            surname_textField.clear();
            date_textField.getEditor().clear();
            status_textField.clear();

    }

    @FXML
    void deleteAttendance(ActionEvent event) {

        StudentAttendance selectedStudent = table.getSelectionModel().getSelectedItem();

        if (selectedStudent != null) {

            table.getItems().remove(selectedStudent);
        } else {
            attention_message.setText("Please select student!");
        }
    }

    @FXML
    void saveToTxt(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            TxtExporter.exportToTxt(file.getAbsolutePath(), table.getItems());
        }
    }


}

