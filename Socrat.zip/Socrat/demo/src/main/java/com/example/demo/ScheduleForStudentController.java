package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class ScheduleForStudentController {

    @FXML
    private Button backBttn;

    @FXML
    public void studentBack(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("menu-student.fxml");
    }

}
